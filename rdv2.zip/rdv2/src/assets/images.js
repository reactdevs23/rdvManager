import logo from "./logo.svg";
import foo from "./foo.svg";
import activeFoo from "./activeFoo.svg";
import bar from "./bar.svg";
import activeBar from "./activeBar.svg";

export { logo, foo, bar, activeBar, activeFoo };
